# **Change Log**
## **17.4.2023**
- finished the changelog
- finish the readme
- remove -wall from Makefile
- add support for icmpv6, icmpv4, arp, mdl, ndp
- data print function
- fix code documentation
- add siginit handler
## **16.4.2023**
- add support for ipv6, ipv4, tcp, udp
- add manual filter fetching
- if none protocols specified, use all of them
- add error_exit funcion, and list all interfaces when -i parameter used without argumetns
- add gitignore add todo
## **15.4.2023**
- add readme, changelog, makefile
- add ipk-sniffer.cpp